/* generated configuration header file - do not edit */
#ifndef R_GPT_CFG_H_
#define R_GPT_CFG_H_
#define GPT_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define SYNERGY_NOT_DEFINED (0xFFFFFFFF)
#if (SYNERGY_NOT_DEFINED != 1)
#define GPT_INSTANCE_CHANNEL_0     (1)
#else
#define GPT_INSTANCE_CHANNEL_0     (0)
#endif
#if (SYNERGY_NOT_DEFINED != SYNERGY_NOT_DEFINED)
#define GPT_INSTANCE_CHANNEL_1     (1)
#else
#define GPT_INSTANCE_CHANNEL_1     (0)                 
#endif
#if (SYNERGY_NOT_DEFINED != SYNERGY_NOT_DEFINED)
#define GPT_INSTANCE_CHANNEL_2     (1)
#else
#define GPT_INSTANCE_CHANNEL_2     (0)                 
#endif
#if (SYNERGY_NOT_DEFINED != SYNERGY_NOT_DEFINED)
#define GPT_INSTANCE_CHANNEL_3     (1)
#else
#define GPT_INSTANCE_CHANNEL_3     (0)                 
#endif
#if (SYNERGY_NOT_DEFINED != SYNERGY_NOT_DEFINED)
#define GPT_INSTANCE_CHANNEL_4     (1)
#else
#define GPT_INSTANCE_CHANNEL_4     (0)                 
#endif
#if (SYNERGY_NOT_DEFINED != SYNERGY_NOT_DEFINED)
#define GPT_INSTANCE_CHANNEL_5     (1)
#else
#define GPT_INSTANCE_CHANNEL_5     (0)                 
#endif
#if (SYNERGY_NOT_DEFINED != SYNERGY_NOT_DEFINED)
#define GPT_INSTANCE_CHANNEL_6     (1)
#else
#define GPT_INSTANCE_CHANNEL_6     (0)                 
#endif
#if (SYNERGY_NOT_DEFINED != SYNERGY_NOT_DEFINED)
#define GPT_INSTANCE_CHANNEL_7     (1)
#else
#define GPT_INSTANCE_CHANNEL_7     (0)                 
#endif
#if (SYNERGY_NOT_DEFINED != SYNERGY_NOT_DEFINED)
#define GPT_INSTANCE_CHANNEL_8     (1)
#else
#define GPT_INSTANCE_CHANNEL_8     (0)                 
#endif
#if (SYNERGY_NOT_DEFINED != SYNERGY_NOT_DEFINED)
#define GPT_INSTANCE_CHANNEL_9     (1)
#else
#define GPT_INSTANCE_CHANNEL_9     (0)                 
#endif
#if (SYNERGY_NOT_DEFINED != SYNERGY_NOT_DEFINED)
#define GPT_INSTANCE_CHANNEL_10     (1)
#else
#define GPT_INSTANCE_CHANNEL_10     (0)                 
#endif
#if (SYNERGY_NOT_DEFINED != SYNERGY_NOT_DEFINED)
#define GPT_INSTANCE_CHANNEL_11     (1)
#else
#define GPT_INSTANCE_CHANNEL_11     (0)                 
#endif
#if (SYNERGY_NOT_DEFINED != SYNERGY_NOT_DEFINED)
#define GPT_INSTANCE_CHANNEL_12     (1)
#else
#define GPT_INSTANCE_CHANNEL_12     (0)                 
#endif
#if (SYNERGY_NOT_DEFINED != SYNERGY_NOT_DEFINED)
#define GPT_INSTANCE_CHANNEL_13     (1)
#else
#define GPT_INSTANCE_CHANNEL_13     (0)                 
#endif
#undef SYNERGY_NOT_DEFINED
#endif /* R_GPT_CFG_H_ */
