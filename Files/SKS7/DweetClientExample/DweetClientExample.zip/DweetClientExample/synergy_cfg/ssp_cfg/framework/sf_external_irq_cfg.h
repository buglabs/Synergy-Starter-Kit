/* generated configuration header file - do not edit */
#ifndef SF_EXTERNAL_IRQ_CFG_H_
#define SF_EXTERNAL_IRQ_CFG_H_
#define SF_EXTERNAL_IRQ_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#endif /* SF_EXTERNAL_IRQ_CFG_H_ */
