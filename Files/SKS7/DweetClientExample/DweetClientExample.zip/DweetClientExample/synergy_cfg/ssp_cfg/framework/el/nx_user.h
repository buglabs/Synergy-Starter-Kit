/* generated configuration header file - do not edit */
#ifndef NX_USER_H_
#define NX_USER_H_
#if (SYNERGY_NOT_DEFINED)
#include "nx_src_user.h"
#endif
#endif /* NX_USER_H_ */
