/* generated messaging header file - do not edit */
#ifndef SF_MESSAGE_PAYLOADS_H_
#define SF_MESSAGE_PAYLOADS_H_
typedef union u_sf_message_payload
{
} sf_message_payload_t;
#endif /* SF_MESSAGE_PAYLOADS_H_ */
