/* generated messaging source file - do not edit */
#include "sf_message.h"
#ifndef SF_MESSAGE_CFG_QUEUE_SIZE
#define SF_MESSAGE_CFG_QUEUE_SIZE (16)
#endif
sf_message_subscriber_list_t * p_subscriber_lists[] =
{ NULL };
void g_message_init(void);
void g_message_init(void)
{
}
