/* generated thread source file - do not edit */
#include "dweet_thread.h"

TX_THREAD dweet_thread;
void dweet_thread_create(void);
static void dweet_thread_func(ULONG thread_input);
/** Alignment requires using pragma for IAR. GCC is done through attribute. */
#if defined(__ICCARM__)
#pragma data_alignment = BSP_STACK_ALIGNMENT
#endif
static uint8_t dweet_thread_stack[8192] BSP_PLACE_IN_SECTION(".stack.dweet_thread") BSP_ALIGN_VARIABLE(BSP_STACK_ALIGNMENT);
void dweet_thread_create(void)
{
    /* Initialize each kernel object. */

    tx_thread_create (&dweet_thread, (CHAR *) "Dweet Thread", dweet_thread_func, (ULONG) NULL, &dweet_thread_stack,
                      8192, 1, 1, 1, TX_DONT_START);
}

static void dweet_thread_func(ULONG thread_input)
{
    /* Not currently using thread_input. */
    SSP_PARAMETER_NOT_USED (thread_input);

    /* Initialize each module instance. */

    /* Enter user code for this thread. */
    dweet_thread_entry ();
}
