/* generated thread header file - do not edit */
#ifndef DEVICES_THREAD_H_
#define DEVICES_THREAD_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
void devices_thread_entry(void);
#include "r_sci_i2c.h"
#include "r_i2c_api.h"
#ifdef __cplusplus
extern "C"
{
#endif
extern const i2c_cfg_t pmodB_cfg;
/** I2C on SCI Instance. */
extern const i2c_master_instance_t pmodB;
#ifdef NULL
#define I2C_ON_SCI_CALLBACK_USED_pmodB (0)
#else
#define I2C_ON_SCI_CALLBACK_USED_pmodB (1)
#endif
#if I2C_ON_SCI_CALLBACK_USED_pmodB
void NULL(i2c_callback_args_t * p_args);
#endif
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* DEVICES_THREAD_H_ */
