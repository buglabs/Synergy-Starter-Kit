/* generated thread header file - do not edit */
#ifndef DWEET_THREAD_H_
#define DWEET_THREAD_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
void dweet_thread_entry(void);
#ifdef __cplusplus
extern "C"
{
#endif
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* DWEET_THREAD_H_ */
