/**********************************************************************************************************************
 * File Name    :  devices_thread_entry.c
 * Description  :  Use SSP hardware APIs to expose physical data sources to the Dweet client.
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 *
 * @brief Expose physical data sources to the Dweet client.
 *
 * This is an example of how to use the DweetLib with SSP hardware interface APIs.
 *
 * First, we use the Dweet_Register_Global API to tell the DweetLib client to include led_status in this application's
 * Dweet payload.  We then configure the thread to sample the hardware interface (gpio pin) at a set interval (every
 * 100ms in this example).
 *
 * @{
 **********************************************************************************************************************/


#include "devices_thread.h"
#include "dweet.h"

#define RED_LED     IOPORT_PORT_06_PIN_01

void devices_thread_entry(void);
/* Devices Thread entry function */
void devices_thread_entry(void)
{
    static UINT led_level;
    static UINT led_status;
    Dweet_Register_Global("led", DWEET_PROPERTY_TYPE_UINT, (void *) (&led_status));
	tx_thread_sleep(100);

    while (1) {
        g_ioport.p_api->pinRead(RED_LED, &led_level);
        led_status = !(led_level);
        tx_thread_sleep (100);
    }
}
