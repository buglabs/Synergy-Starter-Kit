/**********************************************************************************************************************
 * File Name    : main_application.c
 * Description  : Main entry for Dweet Client Example application
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 *
 * @defgroup Main Application
 * @brief Example application utilizing the Dweet.io Client Library (@ref DweetLib)
 *
 * This is the main entry point for a typical application using the
 * Dweet Client Library.  It provides the following:
 *
 * Assignment of IP address using DHCP:
 *      - requires the nx_dhcp component in your application
 *      - \#define INIT_DHCP in the file config_app.h to enable
 *
 * Configuration of DNS server address:
 *      - requires the nx_dnx component in your application
 *      - \#define INIT_DNS in the file config_app.h to enable
 *      - If INIT_DHCP is also set, then use the DNS server returned
 * from the DHCP server.
 *
 * Initiate a mainline procedure that sets up the ETK and calls your
 * functions to define timer handlers, data points and Modbus
 * I/O mappings. *
 * @{
 **********************************************************************************************************************/

/** Standard C Includes */
#include <strings.h>
#include <stdio.h>

/** SSP Includes */
#include "bsp_api.h"
#include "r_fmi_api.h"

/** DweetLib Includes */
#include "dweet.h"

/** Application-specific thread headers */
#include "devices_thread.h"
#include "dweet_thread.h"

/** Retrieves Synergy board defined in configuration */
#ifdef BSP_BOARD_S7G2_SK
#define BoardType "SKS7"
#endif
#ifdef BSP_BOARD_S7G2_DK
#define BoardType "DKS7"
#endif

/**
 *  The DEBUG_TRUE symbol is provided as a preprocessor directive in the Debug build configuration.
 *
 *  The initialise_monitor_handles() function adds Semihosting Virtual Console interface to Synergy projects, which
 *  directs printf() statements to the Renesas Debug Virtual Console.  This console is accessible within the Debug
 *  Perspective view when the application is running via hardware debugging session.
 *
 *  For this example application implementation, you must run the Debug configuration at least once in order to
 *  view the board's Thing-Name (e.g. the Board's factory ID).  Implementation using a display or webserver may
 *  not need this functionality.
 *
 *  For standalone operation without the debugger connected standalone operation, Semihosting must be disabled,
 *  otherwise the process will hang.  Switch to the Release configuration, which does not define DEBUG_TRUE.
 */
#ifdef DEBUG_TRUE
    extern void initialise_monitor_handles(void);
#endif

/** declare the threads as SSP */
extern TX_THREAD devices_thread;
extern TX_THREAD dweet_thread;

void tx_application_define_user(void *first_unused_memory);

/** retrieves unique board ID */
void R_FMI_ProductInfoGet(fmi_product_info_t **);
void bzero(void *, size_t);

/** The thing-name used for sending Dweets */
char thing_name[64];
uint16_t thing_name_checksum16;


/**
 * Default Synergy application entry point.
 *
 * Here we set up networking and start the DNS and DHCP configuration
 * threads, then start the mainline thread that configures the Skkynet
 * ETK and implements the event loop.
 *
 * @param first_unused_memory - passed by the system.  We can create
 * stack space and heap after this point.
 */
void tx_application_define_user(void *first_unused_memory)
{
    UINT status;
    fmi_product_info_t *pinfo;
    int i;
    uint16_t *pu16;

    R_FMI_ProductInfoGet(&pinfo);

#ifdef DEBUG_TRUE
    initialise_monitor_handles(); ///<enable printf to e2studio Renesas Debug Virtual Console
#endif

    pu16 = (uint16_t *) (pinfo->unique_id);
    for (i = 0 ; i < 8 ; i++)
	thing_name_checksum16 += pu16[i];
    sprintf(thing_name, "%s-%04x", BoardType, thing_name_checksum16); ///< set thing-name to board's unique factory ID

#ifdef DEBUG_TRUE
    printf("Thing_name is: %s\n", thing_name);
    printf("Visit https://renesas.dweet.io/follow/%s to verify connection.\n", thing_name);
#endif

    /** Set target dweet server URL and port */
    Dweet_Init("renesas.dweet.io", 80);

    /** Provide name of application in Dweet payload */
    Dweet_Register_Global("application", DWEET_PROPERTY_TYPE_STRING, "DweetSynergyDemoClient");

    /** start thread for LED status */
    tx_thread_resume(&devices_thread);

    /** start dweet client thread */
    tx_thread_resume(&dweet_thread);
}
