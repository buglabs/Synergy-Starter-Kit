/**********************************************************************************************************************
 * File Name    :  dweet_thread_entry.c
 * Description  :  Auto-generated SSP thread file.  Launches our main dweet implementation process
 **********************************************************************************************************************/

#include "dweet_thread.h"

void dweet_thread_entry(void);
void dweet_thread_main(void);

/* Dweet Thread entry function */
void dweet_thread_entry(void)
{
    dweet_thread_main();

    while (1)
    {
        tx_thread_sleep (1);
    }
}
