/**********************************************************************************************************************
 * File Name    : dweetlib-utils.h
 * Description  : Internal functions used by Dweet.io Client Library (@ref DweetLib)
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 *
 * @defgroup DweetLib Utility Functions
 * @brief Custom functions used by Dweet.io Client Library
 *
 * Provides custom data types (called "properties") used to encapsulate data variables that will be sent
 * to/from the Dweet.io Client Library.
 *
 * NOTE: DweetLib client users SHOULD NOT modify this file.
 *
 * @{
 **********************************************************************************************************************/

#ifndef _DWEETLIB_UTILS_H_
#define _DWEETLIB_UTILS_H_

#include "dweetlib-properties.h"
#include <stdarg.h>
#include "bsp_api.h"
#include "r_timer_api.h"

typedef struct _dweet_device_ctrl dweet_device_ctrl_t;
typedef struct _dweet_device_cfg dweet_device_cfg_t;
typedef struct _dweet_device_api dweet_device_api_t;
typedef struct _dweet_device_instance dweet_device_instance_t;

#define _DWEET_CTRL_BASE_PROTO_ \
    char const * name; 

struct _dweet_device_ctrl {
    _DWEET_CTRL_BASE_PROTO_
};

#define _DWEET_CFG_BASE_PROTO_ \
    char const * const name; 

struct _dweet_device_cfg {
    _DWEET_CFG_BASE_PROTO_
};

#define _DWEET_API_BASE_PROTO_(INSTANCE_TYPE, SUPER_TYPE)  \
    SUPER_TYPE *superclass; \
    ssp_err_t (* open)(INSTANCE_TYPE *this); \
    ssp_err_t (* close)(INSTANCE_TYPE *this); \
    char const * (* name)(INSTANCE_TYPE *this); \
    char const * (* type)(INSTANCE_TYPE *this); \
    char const * (* description)(INSTANCE_TYPE *this); \
    void (* update)(INSTANCE_TYPE *this); \
    unsigned int (* numberProperties)(INSTANCE_TYPE *this); \
    dweet_property_type_t (* propertyType)(INSTANCE_TYPE *this, unsigned int index); \
    dweet_property_access_t (* propertyAccess)(INSTANCE_TYPE *this, unsigned int index); \
    char const * (* propertyName)(INSTANCE_TYPE *this, unsigned int index); \
    unsigned int (* propertyCount)(INSTANCE_TYPE *this, unsigned int index); \
    ssp_err_t (* getProperty)(INSTANCE_TYPE *this, unsigned int index, void *data); \
    ssp_err_t (* setProperty)(INSTANCE_TYPE *this, unsigned int index, void *data);

struct _dweet_device_api {
    _DWEET_API_BASE_PROTO_(dweet_device_instance_t, void)
};

extern dweet_device_api_t g_dweet_device_api;

struct _dweet_device_instance {
    dweet_device_ctrl_t * p_ctrl;
    dweet_device_cfg_t const * const p_cfg;
    dweet_device_api_t const * const p_api;
};

char *DWEET_Property_GetAsString(dweet_device_instance_t *this, unsigned int index);
char *DWEET_Property_GetAsJSON(dweet_device_instance_t *this, unsigned int index);
ssp_err_t _DWEET_Property_GetInternal(dweet_device_instance_t *thing, dweet_property_entry_t *prop, void *data);

void DWEET_PostErrorMessage(char *format, ...);

char *DWEET_JSON_FindObject(char *name, char *json);

#endif /* _DWEETLIB_UTILS_H_ */
