/**********************************************************************************************************************
 * File Name    : dweetlib-properties.h
 * Description  : Custom data types used by Dweet.io Client Library (@ref DweetLib)
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 *
 * @defgroup DweetLib Properties
 * @brief Custom data type definitions used by Dweet.io Client Library
 *
 * Provides custom data types (called "properties") used to encapsulate data variables that will be sent
 * to/from the Dweet.io Client Library.  In general, the user DOES NOT need to modify this file.
 *
 *
 * @{
 **********************************************************************************************************************/

#ifndef _DWEETLIB_PROPERTIES_H_
#define _DWEETLIB_PROPERTIES_H_

#include <stddef.h>

typedef enum {
    DWEET_PROPERTY_TYPE_INT,
    DWEET_PROPERTY_TYPE_UINT,
    DWEET_PROPERTY_TYPE_SHORT,
    DWEET_PROPERTY_TYPE_USHORT,
    DWEET_PROPERTY_TYPE_DOUBLE,
    DWEET_PROPERTY_TYPE_STRING,
    DWEET_PROPERTY_TYPE_BYTE,
    DWEET_PROPERTY_TYPE_UBYTE,
    DWEET_PROPERTY_TYPE_NONE,
} dweet_property_type_t;

typedef enum {
    DWEET_PROPERTY_ACCESS_NONE,
    DWEET_PROPERTY_ACCESS_READ_ONLY,
    DWEET_PROPERTY_ACCESS_WRITE_ONLY,
    DWEET_PROPERTY_ACCESS_READ_WRITE,
} dweet_property_access_t;

typedef struct {
    char *name;
    dweet_property_type_t type;
    unsigned int offset;
    unsigned int size;
    unsigned int count;
    dweet_property_access_t access;
} dweet_property_entry_t;


#define ZeOffsetOf(p_type,field) \
        ((Cardinal) (((char *) (&(((p_type)NULL)->field))) - ((char *) NULL)))

size_t DWEET_Property_Size(dweet_property_type_t t);

#endif /* _DWEETLIB_PROPERTIES_H_ */
