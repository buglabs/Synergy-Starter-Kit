/**********************************************************************************************************************
 * File Name    : dweet.h
 * Description  : APIs and settings to use the Dweet.io Client Library (@ref DweetLib)
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 *
 * @defgroup DweetLib Header
 * @brief DweetLib configuration and APIs
 *
 * Provides application level functions and settings that interface with the Dweet.io Client Library (@ref DweetLib)
 *
 * @{
 **********************************************************************************************************************/

#ifndef _DWEET_H_
#define _DWEET_H_

#include "dweetlib-utils.h"
#include "nx_api.h"
#include "nx_dns.h"


/** Setting this to 1 will add the number of Dweets sent in the active session to every Dweet payload */
#define INCLUDE_DWEET_COUNT 1


/** Initialize client by setting target server & port (DEFAULT: http://dweet.io:80) */
extern void Dweet_Init(char *hostname, unsigned int port);


/** Provides simple payload wrapper for data variables
 *
 * @param name - Name of sensor/data signal (e.g. "Temperature")
 * @param type - Specify the data type to expect in the value provided by choosing from the dweet_property_types
 *               defined in @ref dweetlib-properties.h
 * @param ptr -  pointer to location where sensor/data value is stored
 * @return
 */
extern ssp_err_t Dweet_Register_Global(char *name, dweet_property_type_t type, void *ptr);


/** Provides verbose payload wrapper for compatible hardware device drivers using DweetLib's driver utilities.
 *  NOTE: Not utilized in current example application
 */
extern ssp_err_t Dweet_Register_Instance(dweet_device_instance_t * const this);

/** In your networking thread, use this API to provide the DweetLib client with references to the NetX instantiation  */
extern void Dweet_Use_Ethernet(NX_IP *enet, NX_DNS *dns, NX_PACKET_POOL *pool);

/** Sends a single Dweet.  Payload is comprised of the meta data and latest values of the variables passed to
 *  the Dweet_Register_Global() and Dweet_Register_Instance() functions.
 */
extern void Dweet_Send();

/** Retrieves latest Dweet from the devices' send channel (i.e. {thing-name}-send )
 *  For example, if your board's thing-name is set to 'TEST-BOARD', you can send a key:value pair
 *  by issuing a HTTP GET request to http://dweet.io/dweet/for/TEST-BOARD-send?key=value
 *
 *  @param buffer - Provide a character buffer to store latest value
 *  @param length - Specify length of the buffer provided
 *  @return int
 *
 */
extern int Dweet_GetLatestFor(char *buffer, size_t length);


#endif /* _DWEET_H_ */
