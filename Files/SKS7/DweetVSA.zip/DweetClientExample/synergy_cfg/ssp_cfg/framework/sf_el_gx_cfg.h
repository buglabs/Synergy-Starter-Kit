/* generated configuration header file - do not edit */
#ifndef SF_EL_GX_CFG_H_
#define SF_EL_GX_CFG_H_
#define SF_EL_GX_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#endif /* SF_EL_GX_CFG_H_ */
