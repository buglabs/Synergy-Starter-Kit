/* generated configuration header file - do not edit */
#ifndef SF_EL_UX_CFG_H_
#define SF_EL_UX_CFG_H_
#if (0)
#define UX_HOST_VBUS_ENABLE_LOW
#endif
#if defined(BSP_BOARD_S7G2_SK)
#ifndef UX_HOST_VBUS_ENABLE_LOW
#define UX_HOST_VBUS_ENABLE_LOW
#endif
#endif
#endif /* SF_EL_UX_CFG_H_ */
