/* generated configuration header file - do not edit */
#ifndef SF_WIFI_GT202_CFG_H_
#define SF_WIFI_GT202_CFG_H_
#define SF_WIFI_GT202_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define SF_WIFI_GT202_CFG_ONCHIP_STACK_SUPPORT  (0)
#endif /* SF_WIFI_GT202_CFG_H_ */
