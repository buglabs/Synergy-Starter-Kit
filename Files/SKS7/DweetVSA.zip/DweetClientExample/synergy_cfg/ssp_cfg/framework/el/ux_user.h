/* generated configuration header file - do not edit */
#ifndef UX_USER_H_
#define UX_USER_H_
#if (SYNERGY_NOT_DEFINED)
#include "ux_src_user.h"
#endif
#endif /* UX_USER_H_ */
