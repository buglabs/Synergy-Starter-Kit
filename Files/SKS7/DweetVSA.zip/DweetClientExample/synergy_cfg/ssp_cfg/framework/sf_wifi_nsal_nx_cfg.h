/* generated configuration header file - do not edit */
#ifndef SF_WIFI_NSAL_NX_CFG_H_
#define SF_WIFI_NSAL_NX_CFG_H_
#define SF_WIFI_NSAL_NX_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#endif /* SF_WIFI_NSAL_NX_CFG_H_ */
