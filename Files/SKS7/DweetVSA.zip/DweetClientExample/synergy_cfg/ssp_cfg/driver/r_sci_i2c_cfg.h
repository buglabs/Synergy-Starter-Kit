/* generated configuration header file - do not edit */
#ifndef R_SCI_I2C_CFG_H_
#define R_SCI_I2C_CFG_H_
#define SCI_SIIC_CFG_PREREQUISITE_CHECKING_ENABLE 1
#define SCI_SIIC_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#endif /* R_SCI_I2C_CFG_H_ */
