#include "devices_thread.h"
#include "dweet.h"

#define RED_LED     IOPORT_PORT_06_PIN_01

void devices_thread_entry(void);
/* Devices Thread entry function */
void devices_thread_entry(void)
{
    static UINT led_level;
    static UINT led_status;
    Dweet_Register_Global("led", ZE_PROPERTY_TYPE_UINT, (void *) (&led_status));
	tx_thread_sleep(100);

    while (1) {
        g_ioport.p_api->pinRead(RED_LED, &led_level);
        led_status = !(led_level);
        tx_thread_sleep (100);
    }
}
