/*
 * main_application.c
 *
 *  Created on: May 14, 2016
 *      Author: Mike McDonald @ KISStek.com
 */

#include <strings.h>
#include <stdio.h>

#include "dweet.h"

#include "bsp_api.h"
#include "r_fmi_api.h"

#include "devices_thread.h"
#include "network_thread.h"

/* declare the threads as SSP doesn't define them in hte header files like it should */
extern TX_THREAD devices_thread;
extern TX_THREAD network_thread;

extern void initialise_monitor_handles(void);


char thing_name[64];
uint16_t thing_name_checksum16;

void tx_application_define_user(void *first_unused_memory);
void R_FMI_ProductInfoGet(fmi_product_info_t **);
void bzero(void *, size_t);

void tx_application_define_user(void *first_unused_memory)
{
    UINT status;
    fmi_product_info_t *pinfo;
    int i;
    uint16_t *pu16;

    R_FMI_ProductInfoGet(&pinfo);

#ifdef BSP_BOARD_S7G2_SK
#define BoardType "SKS7"
#endif
#ifdef BSP_BOARD_S7G2_DK
#define BoardType "DKS7"
#endif

    initialise_monitor_handles(); // enable printf to e2studio Renesas Debug Virtual Console

    pu16 = (uint16_t *) (pinfo->unique_id);
    for (i = 0 ; i < 8 ; i++)
	thing_name_checksum16 += pu16[i];	// bogus -Wconversion warning from int to uint16_t
    sprintf(thing_name, "%s-%04x", BoardType, thing_name_checksum16);

    printf("Thing_name is: %s\n", thing_name);
    printf("Visit https://dweet.io/follow/%s to verify connection.\n", thing_name);

    Dweet_Init("dweet.io", 80);
    Dweet_Register_Global("application", ZE_PROPERTY_TYPE_STRING, "DweetSynergyDemoClient");

    tx_thread_resume(&devices_thread);
    tx_thread_resume(&network_thread);
}
