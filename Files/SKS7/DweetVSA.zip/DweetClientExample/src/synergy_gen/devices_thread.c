/* generated thread source file - do not edit */
#include "devices_thread.h"

TX_THREAD devices_thread;
void devices_thread_create(void);
static void devices_thread_func(ULONG thread_input);
/** Alignment requires using pragma for IAR. GCC is done through attribute. */
#if defined(__ICCARM__)
#pragma data_alignment = BSP_STACK_ALIGNMENT
#endif
static uint8_t devices_thread_stack[8192] BSP_PLACE_IN_SECTION(".stack.devices_thread") BSP_ALIGN_VARIABLE(BSP_STACK_ALIGNMENT);
#if I2C_ON_SCI_CALLBACK_USED_pmodB
#if defined(__ICCARM__)
#define NULL_WEAK_ATTRIBUTE
#pragma weak NULL                            = NULL_internal
#elif defined(__GNUC__)
#define NULL_WEAK_ATTRIBUTE       __attribute__ ((weak, alias("NULL_internal")))
#endif
void NULL(i2c_callback_args_t * p_args) NULL_WEAK_ATTRIBUTE;
#endif
i2c_ctrl_t pmodB_ctrl;
const i2c_cfg_t pmodB_cfg =
{ .channel = 0, .rate = I2C_RATE_STANDARD, .slave = 0x43, .addr_mode = I2C_ADDR_MODE_7BIT, .sda_delay = 900,
  .p_callback = NULL, .p_context = (void *) &pmodB, };
/* Instance structure to use this module. */
const i2c_master_instance_t pmodB =
{ .p_ctrl = &pmodB_ctrl, .p_cfg = &pmodB_cfg, .p_api = &g_i2c_master_on_sci };

#if I2C_ON_SCI_CALLBACK_USED_pmodB
/*******************************************************************************************************************//**
 * @brief      This is a weak example callback function.  It should be overridden by defining a user callback function 
 *             with the prototype below.
 *               - void NULL(i2c_callback_args_t * p_args)
 *
 * @param[in]  p_args  Callback arguments used to identify what caused the callback.
 **********************************************************************************************************************/
void NULL_internal(i2c_callback_args_t * p_args);
void NULL_internal(i2c_callback_args_t * p_args)
{
    /** Do nothing. */
    SSP_PARAMETER_NOT_USED(p_args);
}
#endif
void devices_thread_create(void)
{
    /* Initialize each kernel object. */

    tx_thread_create (&devices_thread, (CHAR *) "Devices Thread", devices_thread_func, (ULONG) NULL,
                      &devices_thread_stack, 8192, 3, 3, 1, TX_DONT_START);
}

static void devices_thread_func(ULONG thread_input)
{
    /* Not currently using thread_input. */
    SSP_PARAMETER_NOT_USED (thread_input);

    /* Initialize each module instance. */

    /* Enter user code for this thread. */
    devices_thread_entry ();
}
