/* generated thread source file - do not edit */
#include "network_thread.h"

TX_THREAD network_thread;
void network_thread_create(void);
static void network_thread_func(ULONG thread_input);
/** Alignment requires using pragma for IAR. GCC is done through attribute. */
#if defined(__ICCARM__)
#pragma data_alignment = BSP_STACK_ALIGNMENT
#endif
static uint8_t network_thread_stack[8192] BSP_PLACE_IN_SECTION(".stack.network_thread") BSP_ALIGN_VARIABLE(BSP_STACK_ALIGNMENT);
void network_thread_create(void)
{
    /* Initialize each kernel object. */

    tx_thread_create (&network_thread, (CHAR *) "Network Thread", network_thread_func, (ULONG) NULL,
                      &network_thread_stack, 8192, 1, 1, 1, TX_DONT_START);
}

static void network_thread_func(ULONG thread_input)
{
    /* Not currently using thread_input. */
    SSP_PARAMETER_NOT_USED (thread_input);

    /* Initialize each module instance. */

    /* Enter user code for this thread. */
    network_thread_entry ();
}
