/* generated thread header file - do not edit */
#ifndef NETWORK_THREAD_H_
#define NETWORK_THREAD_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
void network_thread_entry(void);
#endif /* NETWORK_THREAD_H_ */
