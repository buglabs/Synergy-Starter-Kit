#include "network_thread.h"

void network_thread_entry(void);
void network_thread_main(void);

/* Network Thread entry function */
void network_thread_entry(void)
{
    network_thread_main();

    while (1)
    {
        tx_thread_sleep (1);
    }
}
